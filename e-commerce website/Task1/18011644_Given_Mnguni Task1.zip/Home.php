<?php

 $con=mysqli_connect('localhost','root','','Kamogelo_mnguni');
session_start();


if(isset($_POST['Show_items']))
{
	
	
	
	
	
}



# reference code

?>



<!DOCTYPE html>
<html>

<head>
     
</head>

<body>
<div>
<?php



  $allProducts = "SELECT * FROM tbl_Products ORDER BY id ASC";
    
      $Foundit= mysqli_query($con,$allProducts  );
      if(mysqli_num_rows($Foundit) >0)
        {
		while($row=mysqli_fetch_array($results))
	{
	?>
		<div>
		
		<form method="post"= action="Home.php"<?php echo $row["id"];?>>
		
		<h4 class="text-info">  <?php echo $row["pname"];?>    </h4><br>
		
		<h4 >R<?php  echo $row["Price"];?>    </h4><br>
		<img src="<?php echo $row["image"];?> </img><br>
		<h4 class="text-info">  <?php echo $row["qnty"];?>    </h4><br>
		<input type="text" name="quantity" value="1"/>
		<input type="hidden" name="hidden_name" <?php echo $row["name"];?>"/>
		<input type="hidden" name="hidden_price" "<?php echo $row["price"];?>"/>
		<input type="submit" name="add_to_cart" style="margin-top:5px"class ="btn"/>
		
		
		</form>
		</div>
		<?php
		
	}
}
           
        


	
?>
  </div>


</body>
</html>


