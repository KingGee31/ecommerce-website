<?php

 $con=mysqli_connect('localhost','root','','18011644_Given_Mnguni');








// sql to create table
	$Ctable = "CREATE TABLE `tbl_Customers` (
		  `cid` int(10) NOT NULL AUTO_INCREMENT,
		  `fname` varchar(50) NOT NULL,
		  `lname` varchar(50) NOT NULL,
		  `email` varchar(50) NOT NULL,
		  `password` varchar(200) NOT NULL,
		  PRIMARY KEY (`cid`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1";

		$Ptable = "CREATE TABLE `tbl_Products` (
		  `pid` int(10) NOT NULL AUTO_INCREMENT,
		  `pname` varchar(50) NOT NULL,
		  `price` decimal(10,2) NOT NULL,
		  `image` varchar(50) NOT NULL,
		  `qnty` int(10) NOT NULL,
		  PRIMARY KEY (`pid`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$con->query($Ctable);
$con->query($Ptable);

# variable of table name i wanna search 
$Check_Table="tbl_Customers";
#Search for a table that look like the variable name i've declared above into database
$Find=$con->query("show tables like '{$Check_Table}'");
# if the table is found i am going to delete it
if(mysqli_num_rows($Find)==1)
{
	#deleting the table
	$DropTable="Drop table tbl_Customers";
	$con->query($DropTable);
	# and recreating the table
		$Ctable = "CREATE TABLE `tbl_Customers` (
		  `cid` int(10) NOT NULL AUTO_INCREMENT,
		  `fname` varchar(50) NOT NULL,
		  `lname` varchar(50) NOT NULL,
		  `email` varchar(50) NOT NULL,
		  `password` varchar(200) NOT NULL,
		  PRIMARY KEY (`cid`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1";
	$con->query($Ctable);
	#calling methods
	CreateFilePopulatingTableCustomer();
	PopulatingProductTable();
}


# A method to populating a table tbl_Customer with textfile data  
Function CreateFilePopulatingTableCustomer()
{
	global $con;
	
# Creating a and populating a file
$UserInfo="Kamogelo,Mnguni,mngunigiven59@gmail.com,Msweswe\n";
$UserInfo.="Steven,Jonson,Steve01@gmail.com,Admin1\n";
$UserInfo.="Stanley,Williams,Willy@gmail.com,123\n";
$UserInfo.="Jones,Mayengane,Jonny@gmail.com,J0n3y\n";
$UserInfo.="Peter,Maluleka,Petoza98@gmail.com,Up62\n";
$UserInfo.="Shane,Wilson,wilson05@gmail.com,shane321\n";
$UserInfo.="Modiegi,Lekala,lekalamodiegi1@gmail.com,Moddy\n";
$UserInfo.="Caroline,Nkwoana,caronkwana223@gmail.com,Candy\n";
$UserInfo.="Tumelo,Mashiane,Tumi100@gmail.com,Tza\n";
$UserInfo.="Given,Kutumela,Kutumela121@gmail.com,SWAT37\n";
$UserInfo.="Given,Dladla,Dladla67@gmail.com,Mgisto\n";
$UserInfo.="Given,Mnguni,Given123@gmail.com,GiyaNca\n";
$UserInfo.="Bongani,Sbiya,Sbeko00@gmail.com,Dzwamari\n";
$UserInfo.="Tebogo,Makhosa,Tebza90@gmail.com,T3bza\n";
$UserInfo.="Lethabo,Dube,Prince59@gmail.com,zwai\n";
$UserInfo.="Bongani,Mahlangu,hlangu1000@gmail.com,Khoks\n";
$UserInfo.="Tshepiso,Nkadimeng,Z1@gmail.com,D1\n";
$UserInfo.="Mandla,Mgidi,Korry1@gmail.com,ABC123\n";
$UserInfo.="Dineo,Magana,Magana190@gmail.com,YOU80\n";
$UserInfo.="Xolile,Mthimunye,xoli09@gmail.com,Candy121\n";
$UserInfo.="Scelo,Mtshweni,sceluthando500@gmail.com,Duga\n";
$UserInfo.="Lindiwe,Kabini,lindo12@gmail.com,naledi987\n";
$UserInfo.="Leon,Mtukudzi,tau356@gmail.com,Leon\n";
$UserInfo.="Kagiso,Mavuso,vuso88@gmail.com,KG\n";
$UserInfo.="Ruth,Mfuma,mfumaruth171@gmail.com,ruth6\n";
$UserInfo.="Njabulo,Maluleka,maluleka090@gmail.com,Nm\n";
$UserInfo.="Lindokuhle,Jiyane,ljiyane5000@gmail.com,LJ031\n";
$UserInfo.="Sobukwe,Mkhwanazi,mkhwanazi01@gmail.com,kwe900\n";
$UserInfo.="Nelson,Ali,nelsonli66@gmail.com,NELSONNN\n";
$UserInfo.="Tony,Mwale,mwaletony22@gmail.com,toni\n";

$FileName="UserData.txt"; # my file name
File_put_contents($FileName,$UserInfo) ; 

$file='UserData.txt';
$data=file($file) or die ("Could not read file to array");# opening file and store it's values to array

foreach($data as $line)
{
	list($Fname,$Lname,$Email,$Password)=explode (",",$line);
	
	$qry="INSERT INTO tbl_Customers (Fname, Lname, Email, Password) VALUES ( '$Fname', '$Lname', '$Email', '$Password');";
	
	$con->query($qry);
	

	
}
}
#creating a method to create and load
function PopulatingProductTable()
{
	global $con;
$ProductInfo.="Apple,18.00,image\\A.jpg,5\n";
$ProductInfo.="Banana,22.00,image\\b.jpg,10\n";
$ProductInfo.="strewberry,25.00,image\\Sb.jpg,5\n";
$ProductInfo.="watermelon,60.00,image\\W.jpg,20\n";
$ProductInfo.="Kiwi fruit each,3.50,image\\k.jpg,6\n";
$ProductInfo.="Beef chuck per Kg,94.99,image\\Ch.jpg,50\n";
$ProductInfo.="Beef Oxtail per Kg,99.99,image\\ox.jpg,30\n";
$ProductInfo.="Beef Mince per Kg,65.99,image\\mm.jpg,10\n";
$ProductInfo.="Pork Cabanossi  per Kg,280.99,image\\kb.jpg,5\n";
$ProductInfo.="Beef Boerewors  per Kg,99.99,image\\bw.jpg,15\n";
$ProductInfo.="Carrots per Kg,19.00,image\\C.jpg,6\n";
$ProductInfo.="Onion per Kg,49.99,image\\o.jpg,6\n";
$ProductInfo.="Potatoes per Kg,44.16,image\\p.jpg,6\n";
$ProductInfo.="Broccoli per Kg,34.00,image\\Bb.jpg,6\n";
$ProductInfo.="Cucumber each,12.50,image\\Cc.jpg,6\n";

$Product_txt_Name="item.txt"; # my file name
File_put_contents($Product_txt_Name,$ProductInfo) ; 


$Pfile='item.txt';
$data=file($Pfile) or die ("Could not read file to array");# opening file and store it's values to array

foreach($data as $line)
{
	list($Pname,$Price,$image,$qnty)=explode (",",$line);
	
	$qry="INSERT INTO tbl_Products (pname, price, image, qnty) VALUES ( '$Pname', '$Price', '$image', '$qnty');";
	
	$con->query($qry);
	

	
}
	
}

?>