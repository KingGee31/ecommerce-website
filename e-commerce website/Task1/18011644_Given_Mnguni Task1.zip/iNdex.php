<?php





?>

<!DOCTYPE html>
<html>

<head>
    <title>Woza nazo Super markert </title>
      
</head>

<body>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>

<p>Ola "Hi" ,Welocome  to woza nazo no1 super markert.......The only super markert around kasi that issues fresh goodies at all times and has online shopping center. <br>we have all you want all day, every day, come shop with us .......feel at home!!!</p>
<br>
<br>
<br>
       <a href="Register.html"> Click here to Register </a> <br>   <a href="Login.html"> Click here to Login
</center>


</body>
</html>