<?php

 $con=mysqli_connect('localhost','root','','18011644_Given_Mnguni');

#declaring a variable that is going to dispaly error msg
$Erro_msg=Null;



# this is the action that is goingto take place when register button is clicked 
if(isset($_POST['REGISTER']))
{
	
# taking values from registration form and assign them to variables
$email=mysqli_real_escape_string($con,$_POST['Email']);
$Password=mysqli_real_escape_string($con,$_POST['Password']);



#i tried my level best to code what was required but it kept on giving me errors so i had to comment the code to avoid errors and keep code going
/*
# query to check if password exist in database
$searchEmail = "SELECT * FROM tbl_Customers WHERE email = '$email' ";

$searchPassword = "SELECT * FROM tbl_Customers WHERE password = '$Password' ";
# query to get one specific user


	$Valid_User="SELECT * FROM tbl_Customers WHERE email='$email' AND password='$Password'";
	
	  $FoundValidU= mysqli_query($con,$Valid_User );
      $FoundEmail= mysqli_query($con,$searchEmail );
	  $FoundPassword= mysqli_query($con,searchPassword);
		
		
		
	# if email exist it wont be removed
      if(mysqli_num_rows( $FoundEmail) == 1)
        {
          $email= $_POST['Email'];
        }
		elseif(mysqli_num_rows( $FoundPassword) == 1)
        {
          $Password= $_POST['Password'];
        }
		elseif(mysqli_num_rows( $FoundValidU) == 1)
		{
			header('location:Home.php');
		}
		elseif(mysqli_num_rows( $FoundValidU) == 0)
		{
			#if the user both email and password are not found in table they will be taken back to registration page
			$Erro_msg="User invalid please click 'register' link below to register";
		}
		else
		{
			# this will remove textbox that doesnot match with the data that is retrieved from the database
		}


	*/
  
	  $searchEmail = "SELECT * FROM tbl_Customers WHERE email = '$email'";
    
      $Foundit= mysqli_query($con,$searchEmail );
      if(mysqli_num_rows($Foundit) == 1)
        {
			#i'm directing a user to another page and a user name along
			$_SESSION['Email']=$email;
				header('location:Home.php');
           
        }
}
?>

<!DOCTYPE html>

<html>
    <head>
        <Style>
		
		body
		{
		background:grey;
		}
		
		
		form {
		border: solid green 1px;
		width: 420px;
		border-radius:5px;
		
		TEXT-ALIGN: CENTER;
		margin:100px auto;
		background:tomato;
		podding: 5px;
		
	
		
		</Style>
    </head>
    <body>
	<div>
	
	

	
	
	</div>
      
	  <br>
	  <br>
	
	  

	  <form action="Login.php" method="POST">
	  <div>
	  <?php
 echo "<br>";
  echo $Erro_msg;
?>
	  <h1>Login form </h1>
	
	  

   <label for="Email">Email :</label><br>
  <input type="Email" id="Email" name="Email" required><br>
  
   <label for="Password">Password:</label><br>
  <input type="Password" id="Password" name="Password" required><br>
  
  
 <input type="submit" name="REGISTER" value="REGISTER"> 
 <br>
 <br>
 <a href="Register.php"> Click here to register</a> 
 <br>
	  </div>
	  
</form>

	
	  
    </body>
</html>